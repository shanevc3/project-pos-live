# Project P.O.S. v0.8.0 — Conversation RC2

## Purpose
Improve voice recovery and make the iPhone Home Screen experience clearer, faster, and more conversational.

## Changes
- Requests microphone access directly before starting browser speech recognition.
- Provides a visible retry path after an accidental permission denial.
- Gives exact iPhone Settings guidance when microphone permission is blocked.
- Detects Safari versus Home Screen mode and displays the active environment.
- Adds adaptive Talk, Listening, Thinking, Speaking, and Permission Needed states.
- Adds live interim transcription in a user message card.
- Adds animated voice-level feedback and clearer status hints.
- Adds one-tap keyboard dictation fallback without treating it as a failure.
- Refreshes the service-worker cache name and uses network-first navigation so updates arrive faster.
- Preserves the existing Four-Brain, event-ledger, local-first, recovery, and governance functionality.

## Important limitation
This update makes the strongest web-platform attempt to recover microphone permission and use speech recognition in the installed Home Screen app. iOS may still deny the Web Speech API in standalone mode on some versions. In that case, keyboard dictation remains available and Safari Talk mode remains the full fallback.
