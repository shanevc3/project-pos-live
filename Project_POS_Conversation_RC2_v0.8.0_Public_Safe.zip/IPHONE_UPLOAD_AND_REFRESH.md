# iPhone Upload and Refresh — v0.8.0

1. In GitHub, open the public `project-pos-live` repository.
2. Upload **the contents of this ZIP**, preserving the `core` and `icons` folders.
3. Replace the existing files when GitHub asks.
4. Commit directly to the deployment branch used by GitHub Pages.
5. Wait for the Pages workflow to finish successfully.
6. Open the live site in Safari and refresh once.
7. Close the Home Screen app completely, then reopen it.
8. Confirm the header reads `v0.8.0 · CONVERSATION RC2`.
9. Tap **Talk**. When iPhone asks for microphone access, choose **Allow**.

If the old version remains cached:
- Open the live site in Safari and add `?v=0.8.0` to the end once.
- Refresh Safari.
- Close and reopen the Home Screen app.
- Only if the version label still remains v0.7.1, remove the Home Screen icon and add it again from Safari.

If permission was previously denied:
- Open **Settings → Apps → Safari → Microphone → Allow**.
- Return to Axiom and tap **Try Voice Again**.
