# Project P.O.S. v0.8.0 — Conversation RC2

GitHub Pages deployment package for Axiom.

Upload the contents of this package to the root of the public `project-pos-live` repository. See `IPHONE_UPLOAD_AND_REFRESH.md` for the exact iPhone-only workflow.

This is a public-safe deployment package. It contains application code and release documentation, not the private project archive.
